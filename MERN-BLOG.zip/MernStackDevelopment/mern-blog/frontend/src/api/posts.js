import axios from 'axios';

// Base URL from .env — all requests go to http://localhost:3000/api
const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL
});

// ── API functions — one per operation ─────────────────────────

// Fetch all posts
export const getAllPosts = async () => {
  const response = await API.get('/posts');
  return response.data; // { success: true, count: N, data: [...] }
};

// Fetch a single post by ID
export const getPostById = async (id) => {
  const response = await API.get(`/posts/${id}`);
  return response.data; // { success: true, data: { post object } }
};

// Create a new post
export const createPost = async (postData) => {
  const response = await API.post('/posts', postData);
  return response.data; // { success: true, data: { new post } }
};

// Update an existing post
export const updatePost = async (id, postData) => {
  const response = await API.put(`/posts/${id}`, postData);
  return response.data; // { success: true, data: { updated post } }
};

// Delete a post
export const deletePost = async (id) => {
  const response = await API.delete(`/posts/${id}`);
  return response.data; // { success: true, message: "..." }
};

