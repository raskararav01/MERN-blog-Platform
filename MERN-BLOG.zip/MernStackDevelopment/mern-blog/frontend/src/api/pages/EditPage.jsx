import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getPostById, updatePost } from '../posts';
import PostForm from '../components/PostForm';
import Loader from '../components/Loader';

function EditPage() {
  const { id } = useParams(); // get :id from the URL /edit/:id
  const navigate = useNavigate();

  const [post,    setPost]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving,  setSaving]  = useState(false);
  const [error,   setError]   = useState(null);

  // Fetch the existing post when page loads
  useEffect(() => {
    async function fetchPost() {
      try {
        const result = await getPostById(id);
        setPost(result.data);
      } catch (err) {
        setError(
          err.response?.data?.error ||
          'Failed to load post'
        );
      } finally {
        setLoading(false);
      }
    }

    fetchPost();
  }, [id]); // re-fetch if id in URL changes

  const handleSubmit = async (formData) => {
    try {
      setSaving(true);
      setError(null);

      await updatePost(id, formData); // PUT to backend

      navigate('/', { state: { message: 'Post updated successfully!' } });

    } catch (err) {
      setError(
        err.response?.data?.error ||
        err.message ||
        'Failed to update post'
      );
      setSaving(false);
    }
  };

  // ── Render states ──────────────────────────────────────────
  if (loading) return <Loader />;

  if (error && !post) {
    return (
      <div className="error-container">
        <h2>Error</h2>
        <p>{error}</p>
        <button className="btn btn-primary" onClick={() => navigate('/')}>
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <div className="page page-narrow">

      <div className="page-header">
        <button className="btn btn-back" onClick={() => navigate('/')}>
          ← Back
        </button>
        <h1>Edit Post</h1>
      </div>

      {error && (
        <div className="alert alert-error">
          ❌ {error}
        </div>
      )}

      {/* Pass existing post data to pre-fill the form */}
      <PostForm
        initialData={post}
        onSubmit={handleSubmit}
        loading={saving}
        submitLabel="Save Changes"
      />

    </div>
  );
}

export default EditPage;

