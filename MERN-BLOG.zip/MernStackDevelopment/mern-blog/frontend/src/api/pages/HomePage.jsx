import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAllPosts } from '../posts';
import PostCard from '../components/PostCard';
import Loader from '../components/Loader';

function HomePage() {
  const [posts,   setPosts]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);
  const navigate = useNavigate();

  // Fetch posts when component mounts
  useEffect(() => {
    async function fetchPosts() {
      try {
        setLoading(true);
        const result = await getAllPosts();
        setPosts(result.data); // result.data is the array of posts
      } catch (err) {
        setError(
          err.response?.data?.error ||  // backend error message
          err.message ||                 // network error
          'Failed to load posts'
        );
      } finally {
        setLoading(false);
      }
    }

    fetchPosts();
  }, []); // [] = run once when component mounts

  // Called by PostCard after successful delete
  const handleDelete = (deletedId) => {
    setPosts(prev => prev.filter(post => post._id !== deletedId));
    // Remove the deleted post from state — no need to re-fetch from server
  };

  // ── Render states ──────────────────────────────────────────
  if (loading) return <Loader />;

  if (error) {
    return (
      <div className="error-container">
        <h2>Something went wrong</h2>
        <p>{error}</p>
        <button
          className="btn btn-primary"
          onClick={() => window.location.reload()}
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="page">

      {/* Header row */}
      <div className="page-header">
        <div>
          <h1>Blog Posts</h1>
          <p className="subtitle">{posts.length} post{posts.length !== 1 ? 's' : ''} total</p>
        </div>
        <button
          className="btn btn-primary"
          onClick={() => navigate('/create')}
        >
          + New Post
        </button>
      </div>

      {/* Empty state */}
      {posts.length === 0 ? (
        <div className="empty-state">
          <p>📝 No posts yet.</p>
          <button
            className="btn btn-primary"
            onClick={() => navigate('/create')}
          >
            Create Your First Post
          </button>
        </div>
      ) : (
        /* Post grid */
        <div className="posts-grid">
          {posts.map(post => (
            <PostCard
              key={post._id}
              post={post}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

    </div>
  );
}

export default HomePage;

