import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPost } from '../posts';
import PostForm from '../components/PostForm';

function CreatePage() {
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async (formData) => {
    try {
      setLoading(true);
      setError(null);

      await createPost(formData); // send to backend

      // Success — go back to home page
      navigate('/', { state: { message: 'Post created successfully!' } });

    } catch (err) {
      setError(
        err.response?.data?.error ||
        err.message ||
        'Failed to create post'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page page-narrow">

      <div className="page-header">
        <button className="btn btn-back" onClick={() => navigate('/')}>
          ← Back
        </button>
        <h1>Create New Post</h1>
      </div>

      {error && (
        <div className="alert alert-error">
          ❌ {error}
        </div>
      )}

      <PostForm
        onSubmit={handleSubmit}
        loading={loading}
        submitLabel="Create Post"
      />

    </div>
  );
}

export default CreatePage;

