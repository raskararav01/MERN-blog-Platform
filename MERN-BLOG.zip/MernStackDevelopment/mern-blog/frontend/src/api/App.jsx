import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import HomePage   from './pages/HomePage';
import CreatePage from './pages/CreatePage';
import EditPage   from './pages/EditPage';
import './App.css';

// Navbar shown on every page
function Navbar() {
  return (
    <nav className="navbar">
      <a href="/" className="nav-brand">📝 MERN Blog</a>
      <span className="nav-tagline">React + Express + MongoDB</span>
    </nav>
  );
}

// Show success message passed via navigation state
function SuccessBanner() {
  const location = useLocation();
  const message  = location.state?.message;

  if (!message) return null;

  return (
    <div className="alert alert-success">
      ✅ {message}
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <div className="container">
        <SuccessBanner />
        <Routes>
          <Route path="/"          element={<HomePage />} />
          <Route path="/create"    element={<CreatePage />} />
          <Route path="/edit/:id"  element={<EditPage />} />
          <Route path="*"          element={
            <div className="error-container">
              <h2>404 — Page Not Found</h2>
              <a href="/">Go Home</a>
            </div>
          } />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;

