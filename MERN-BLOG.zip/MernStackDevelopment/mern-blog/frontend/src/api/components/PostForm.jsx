import { useState } from 'react';

// initialData allows pre-filling the form for editing
function PostForm({ initialData = {}, onSubmit, loading, submitLabel = 'Submit' }) {

  const [formData, setFormData] = useState({
    title:     initialData.title     || '',
    content:   initialData.content   || '',
    author:    initialData.author    || '',
    tags:      initialData.tags      ? initialData.tags.join(', ') : '',
    published: initialData.published !== undefined ? initialData.published : true
  });

  const [errors, setErrors] = useState({});

  // Validate all fields before submitting
  const validate = () => {
    const newErrors = {};
    if (!formData.title.trim())         newErrors.title   = 'Title is required';
    else if (formData.title.length < 3) newErrors.title   = 'Title must be at least 3 characters';
    if (!formData.content.trim())       newErrors.content = 'Content is required';
    else if (formData.content.length < 10) newErrors.content = 'Content must be at least 10 characters';
    if (!formData.author.trim())        newErrors.author  = 'Author is required';
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    // Clear the error for this field as user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return; // stop — don't call onSubmit
    }

    // Convert tags string "mern, nodejs, react" → array ["mern", "nodejs", "react"]
    const processedData = {
      ...formData,
      tags: formData.tags
        ? formData.tags.split(',').map(t => t.trim()).filter(t => t !== '')
        : []
    };

    onSubmit(processedData); // pass processed data up to the page
  };

  return (
    <form className="post-form" onSubmit={handleSubmit} noValidate>

      {/* Title */}
      <div className="form-group">
        <label htmlFor="title">Title *</label>
        <input
          id="title"
          name="title"
          type="text"
          value={formData.title}
          onChange={handleChange}
          placeholder="Enter post title"
          className={errors.title ? 'input-error' : ''}
          disabled={loading}
        />
        {errors.title && <span className="error-msg">{errors.title}</span>}
      </div>

      {/* Author */}
      <div className="form-group">
        <label htmlFor="author">Author *</label>
        <input
          id="author"
          name="author"
          type="text"
          value={formData.author}
          onChange={handleChange}
          placeholder="Your name"
          className={errors.author ? 'input-error' : ''}
          disabled={loading}
        />
        {errors.author && <span className="error-msg">{errors.author}</span>}
      </div>

      {/* Content */}
      <div className="form-group">
        <label htmlFor="content">Content *</label>
        <textarea
          id="content"
          name="content"
          value={formData.content}
          onChange={handleChange}
          placeholder="Write your post content here..."
          rows={8}
          className={errors.content ? 'input-error' : ''}
          disabled={loading}
        />
        {errors.content && <span className="error-msg">{errors.content}</span>}
      </div>

      {/* Tags */}
      <div className="form-group">
        <label htmlFor="tags">Tags (comma-separated)</label>
        <input
          id="tags"
          name="tags"
          type="text"
          value={formData.tags}
          onChange={handleChange}
          placeholder="e.g. mern, nodejs, react"
          disabled={loading}
        />
        <small className="hint">Separate multiple tags with commas</small>
      </div>

      {/* Published toggle */}
      <div className="form-group checkbox-group">
        <label>
          <input
            name="published"
            type="checkbox"
            checked={formData.published}
            onChange={handleChange}
            disabled={loading}
          />
          <span>Publish immediately</span>
        </label>
      </div>

      {/* Submit */}
      <button
        type="submit"
        className="btn btn-primary"
        disabled={loading}
      >
        {loading ? 'Saving...' : submitLabel}
      </button>

    </form>
  );
}

export default PostForm;

