import { useNavigate } from 'react-router-dom';
import { deletePost } from '../posts';

function PostCard({ post, onDelete }) {
  const navigate = useNavigate();

  const handleDelete = async () => {
    const confirmed = window.confirm(
      `Delete "${post.title}"? This cannot be undone.`
    );
    if (!confirmed) return;

    try {
      await deletePost(post._id);
      onDelete(post._id); // tell parent to remove this card from the list
    } catch (err) {
      alert('Failed to delete post. Please try again.');
    }
  };

  const formatDate = (dateStr) =>
    new Date(dateStr).toLocaleDateString('en-IN', {
      day: 'numeric', month: 'long', year: 'numeric'
    });

  return (
    <div className="post-card">

      {/* Published / Draft badge */}
      <span className={`badge ${post.published ? 'published' : 'draft'}`}>
        {post.published ? 'Published' : 'Draft'}
      </span>

      {/* Title */}
      <h2 className="post-title">{post.title}</h2>

      {/* Meta */}
      <div className="post-meta">
        <span>✍️ {post.author}</span>
        <span>📅 {formatDate(post.createdAt)}</span>
      </div>

      {/* Tags */}
      {post.tags && post.tags.length > 0 && (
        <div className="tags">
          {post.tags.map((tag, index) => (
            <span key={index} className="tag">#{tag}</span>
          ))}
        </div>
      )}

      {/* Action buttons */}
      <div className="card-actions">
        <button
          className="btn btn-edit"
          onClick={() => navigate(`/edit/${post._id}`)}
        >
          ✏️ Edit
        </button>
        <button
          className="btn btn-delete"
          onClick={handleDelete}
        >
          🗑️ Delete
        </button>
      </div>

    </div>
  );
}

export default PostCard;
