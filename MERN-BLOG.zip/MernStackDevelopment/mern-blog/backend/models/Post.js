const mongoose = require('mongoose');


const postSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      minlength: [3, 'Title must be at least 3 characters'],
      maxlength: [150, 'Title cannot exceed 150 characters']
    },
    slug: {
      type: String,
      lowercase: true,
      trim: true
    },
    content: {
      type: String,
      required: [true, 'Content is required'],
      minlength: [10, 'Content must be at least 10 characters']
    },
    author: {
      type: String,
      required: [true, 'Author is required'],
      trim: true
    },
    tags: {
      type: [String],
      default: []
    },
    published: {
      type: Boolean,
      default: true
    }
  },
  { timestamps: true }
);


// Synchronous pre-save hook — NO callback parameter needed
postSchema.pre('save', function() {
  if (this.isModified('title') || this.isNew) {
    this.slug = this.title
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-');
  }
});

module.exports = mongoose.model('Post', postSchema);
