require('dotenv').config();
const express      = require('express');
const cors         = require('cors');
const connectDB    = require('./config/database');
const postRoutes   = require('./routes/posts');
const errorHandler = require('./middleware/errorHandler');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ─────────────────────────────────────────────────
app.use(cors({
  origin: 'http://localhost:5173',  // allow only your React dev server
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type']
}));

app.use(express.json());

// ── Routes ─────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({ message: 'MERN Blog API is running' });
});

app.use('/api/posts', postRoutes);

// ── Error handlers (always last) ───────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, error: `Cannot ${req.method} ${req.url}` });
});

app.use(errorHandler);

// ── Start ──────────────────────────────────────────────────────
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
  });
});
