const express = require('express');
const Post    = require('../models/Post');
const router  = express.Router();

// ── GET all posts ──────────────────────────────────────────────
router.get('/', async (req, res, next) => {
  try {
    const posts = await Post.find()
      .sort({ createdAt: -1 })
      .select('title author tags published createdAt slug');

    res.status(200).json({ success: true, count: posts.length, data: posts });
  } catch (err) {
    next(err);
  }
});

// ── GET single post ────────────────────────────────────────────
router.get('/:id', async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({ success: false, error: 'Post not found' });
    }

    res.status(200).json({ success: true, data: post });
  } catch (err) {
    next(err);
  }
});

// ── CREATE post ────────────────────────────────────────────────
router.post('/', async (req, res, next) => {
  try {
    const { title, content, author, tags, published } = req.body;

    const post = new Post({ title, content, author, tags, published });
    await post.save();

    res.status(201).json({ success: true, data: post });
  } catch (err) {
    next(err);
  }
});

// ── UPDATE post ────────────────────────────────────────────────
router.put('/:id', async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({ success: false, error: 'Post not found' });
    }

    const { title, content, author, tags, published } = req.body;

    post.title     = title     ?? post.title;
    post.content   = content   ?? post.content;
    post.author    = author    ?? post.author;
    post.tags      = tags      ?? post.tags;
    post.published = published ?? post.published;

    await post.save();

    res.status(200).json({ success: true, data: post });
  } catch (err) {
    next(err);
  }
});

// ── DELETE post ────────────────────────────────────────────────
router.delete('/:id', async (req, res, next) => {
  try {
    const post = await Post.findByIdAndDelete(req.params.id);

    if (!post) {
      return res.status(404).json({ success: false, error: 'Post not found' });
    }

    res.status(200).json({ success: true, message: `"${post.title}" deleted` });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

