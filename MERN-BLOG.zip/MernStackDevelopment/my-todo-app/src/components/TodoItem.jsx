function TodoItem({ task, onDelete, onToggle }) {
  return (
    <li className={`todo-item ${task.completed ? "completed" : ""}`}>

      {/* Checkbox to toggle completion */}
      <input
        type="checkbox"
        checked={task.completed}
        onChange={() => onToggle(task.id)}
        className="checkbox"
      />

      {/* Task text + date */}
      <div className="task-info">
        <span className="task-text">{task.text}</span>
        <span className="task-date">Added: {task.createdAt}</span>
      </div>

      {/* Delete button */}
      <button
        onClick={() => onDelete(task.id)}
        className="delete-btn"
        title="Delete task"
      >
        🗑️
      </button>

    </li>
  );
}

export default TodoItem;

