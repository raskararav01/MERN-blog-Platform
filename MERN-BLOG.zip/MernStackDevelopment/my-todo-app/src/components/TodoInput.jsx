import { useState } from 'react';

function TodoInput({ onAdd }) {
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = () => {
    // Validation
    if (text.trim() === "") {
      setError("Task cannot be empty.");
      return;
    }
    if (text.trim().length < 3) {
      setError("Task must be at least 3 characters.");
      return;
    }

    onAdd(text);    // call parent's addTask function
    setText("");    // clear input
    setError("");   // clear error
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleSubmit();
  };

  return (
    <div className="input-section">
      <div className="input-row">
        <input
          type="text"
          value={text}
          onChange={e => {
            setText(e.target.value);
            if (error) setError(""); // clear error as user types
          }}
          onKeyDown={handleKeyDown}
          placeholder="Add a new task... (Press Enter)"
          className={error ? "input-error" : ""}
          maxLength={100}
        />
        <button onClick={handleSubmit} className="add-btn">
          Add
        </button>
      </div>

      {error && <p className="error-text">{error}</p>}

      <p className="char-count">{text.length}/100</p>
    </div>
  );
}

export default TodoInput;

