import { useState, useEffect } from "react";
import TodoInput from './components/TodoInput';
import TodoList from './components/TodoList';
import './App.css';

function App() {
  // Master state — all tasks live here
  // Loaded from localStorage on first render
  const [tasks, setTasks] = useState(() => {
    const saved = localStorage.getItem("tasks");
    return saved ? JSON.parse(saved) : [];
  });

  const [filter, setFilter] = useState("all"); 

  // Save to localStorage whenever tasks change
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  // Add task
  const addTask = (text) => {
    const newTask = {
      id: Date.now(),       // simple unique ID using timestamp
      text: text.trim(),
      completed: false,
      createdAt: new Date().toLocaleDateString()
    };
    setTasks(prev => [newTask, ...prev]); // add to top of list
  };

  // Delete task
  const deleteTask = (id) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  };

  // Toggle completed
  const toggleTask = (id) => {
    setTasks(prev =>
      prev.map(task =>
        task.id === id
          ? { ...task, completed: !task.completed }
          : task
      )
    );
  };

  // Clear all completed tasks
  const clearCompleted = () => {
    setTasks(prev => prev.filter(task => !task.completed));
  };

  // Filtered tasks based on current filter
  const filteredTasks = tasks.filter(task => {
    if (filter === "active")    return !task.completed;
    if (filter === "completed") return task.completed;
    return true; // "all"
  });

  const completedCount = tasks.filter(t => t.completed).length;
  const activeCount    = tasks.length - completedCount;

  return (
    <div className="app">
      <div className="todo-container">

        {/* Header */}
        <header className="todo-header">
          <h1>📝 My Tasks</h1>
          <p className="subtitle">
            {activeCount} task{activeCount !== 1 ? "s" : ""} remaining
          </p>
        </header>

        {/* Input Component */}
        <TodoInput onAdd={addTask} />

        {/* Filter Buttons */}
        <div className="filter-bar">
          {["all", "active", "completed"].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={filter === f ? "active-filter" : ""}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        {/* Task List Component */}
        <TodoList
          tasks={filteredTasks}
          onDelete={deleteTask}
          onToggle={toggleTask}
        />

        {/* Footer */}
        {completedCount > 0 && (
          <div className="todo-footer">
            <span>{completedCount} completed</span>
            <button onClick={clearCompleted} className="clear-btn">
              Clear Completed
            </button>
          </div>
        )}

        {/* Empty State */}
        {tasks.length === 0 && (
          <div className="empty-state">
            <p>🎉 No tasks yet. Add one above!</p>
          </div>
        )}

      </div>
    </div>
  );
}

export default App;
