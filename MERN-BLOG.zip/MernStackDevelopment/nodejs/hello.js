console.log(__filename); // full path to this file
console.log(__dirname);  // full path to this folder
console.log(process.platform); // "win32", "linux", "darwin"
console.log(process.version);  // Node.js version
