const express        = require('express');
const path           = require('path');
const logger         = require('./middleware/logger');
const productRoutes  = require('./routes/products');
const userRoutes     = require('./routes/users');

const app  = express();
const PORT = 3000;

// ── Middleware ─────────────────────────────────────────────────
app.use(express.json());
app.use(logger);

// ── Routes ─────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    message: 'MERN Backend API',
    version: '1.0.0',
    endpoints: {
      products: '/api/products',
      users:    '/api/users'
    }
  });
});

app.use('/api/products', productRoutes);
app.use('/api/users',    userRoutes);

// ── 404 Handler ────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: `Cannot ${req.method} ${req.url}`
  });
});

// ── Error Handler ──────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, error: 'Internal server error' });
});

// ── Start ──────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\nServer running at http://localhost:${PORT}`);
  console.log('\nEndpoints:');
  console.log(`  GET  http://localhost:${PORT}/api/products`);
  console.log(`  GET  http://localhost:${PORT}/api/products/1`);
  console.log(`  POST http://localhost:${PORT}/api/products`);
  console.log(`  GET  http://localhost:${PORT}/api/users`);
});
