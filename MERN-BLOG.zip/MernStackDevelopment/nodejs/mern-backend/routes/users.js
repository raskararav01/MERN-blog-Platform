const express = require('express');
const path    = require('path');
const fs      = require('fs').promises;

const router    = express.Router();
const DATA_FILE = path.join(__dirname, '../data/users.json');

async function readUsers() {
  const content = await fs.readFile(DATA_FILE, 'utf8');
  return JSON.parse(content);
}

// GET /api/users
router.get('/', async (req, res) => {
  try {
    const users = await readUsers();
    res.json({ success: true, count: users.length, data: users });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/users/:id
router.get('/:id', async (req, res) => {
  try {
    const users = await readUsers();
    const user  = users.find(u => u.id === parseInt(req.params.id));

    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    res.json({ success: true, data: user });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
