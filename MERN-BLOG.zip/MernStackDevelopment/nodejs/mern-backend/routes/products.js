const express = require('express');
const path    = require('path');
const fs      = require('fs').promises;

const router      = express.Router();
const DATA_FILE   = path.join(__dirname, '../data/products.json');

// Helper: read products from JSON file
async function readProducts() {
  const content = await fs.readFile(DATA_FILE, 'utf8');
  return JSON.parse(content);
}

// Helper: write products back to JSON file
async function writeProducts(products) {
  await fs.writeFile(DATA_FILE, JSON.stringify(products, null, 2), 'utf8');
}

// GET /api/products
router.get('/', async (req, res) => {
  try {
    const products = await readProducts();
    res.json({ success: true, count: products.length, data: products });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/products/:id
router.get('/:id', async (req, res) => {
  try {
    const products = await readProducts();
    const product  = products.find(p => p.id === parseInt(req.params.id));

    if (!product) {
      return res.status(404).json({
        success: false,
        error: 'Product not found'
      });
    }

    res.json({ success: true, data: product });

  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/products
router.post('/', async (req, res) => {
  try {
    const { name, price, category, inStock } = req.body;

    if (!name || !price || !category) {
      return res.status(400).json({
        success: false,
        error: 'name, price, and category are required'
      });
    }

    const products  = await readProducts();
    const newProduct = {
      id:       products.length > 0
                  ? Math.max(...products.map(p => p.id)) + 1
                  : 1,
      name:     name.trim(),
      price:    Number(price),
      category: category.trim(),
      inStock:  inStock !== undefined ? Boolean(inStock) : true
    };

    products.push(newProduct);
    await writeProducts(products);

    res.status(201).json({ success: true, data: newProduct });

  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/products/:id
router.delete('/:id', async (req, res) => {
  try {
    const products = await readProducts();
    const index    = products.findIndex(p => p.id === parseInt(req.params.id));

    if (index === -1) {
      return res.status(404).json({
        success: false,
        error: 'Product not found'
      });
    }

    const deleted = products.splice(index, 1)[0];
    await writeProducts(products);

    res.json({
      success: true,
      message: `"${deleted.name}" deleted`,
      data: deleted
    });

  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
