function logger(req, res, next) {
  const time   = new Date().toISOString();
  const method = req.method.padEnd(7); // align columns
  const url    = req.url;

  console.log(`[${time}] ${method} ${url}`);
  next();
}

module.exports = logger;
