function greet(name) {
  return "Hello, " + name + "!";
}

console.log(greet("Arav")); 
console.log(greet("Student"));
console.log(greet("Varun"));
console.log(greet("Vinit"));
console.log(greet("Pratik"));

const add = (a, b) => {
  return a + b;
};
console.log(add(5, 3));

const add1 = (a, b) => a + b;
console.log(add1(10, 15));

for (let i = 1; i < 11; i++) {
  console.log( 2 * i);
}

const employees = [
  { name: "Rohit", department: "Engineering", salary: 52000 },
  { name: "Virat", department: "Marketing", salary: 85000 },
  { name: "Shubham", department: "Engineering", salary: 99000 },
  { name: "Mahendra", department: "Engineering", salary: 77000 },
  { name: "Narendra", department: "Marketing", salary: 12000 }
];

const engineeringSalaryTotal = employees
  .filter(emp => emp.department === "Engineering")  
  .map(emp => emp.salary)                            
  .reduce((total, salary) => total + salary, 0);    

console.log(`Engineering payroll: ₹${engineeringSalaryTotal}`); 

